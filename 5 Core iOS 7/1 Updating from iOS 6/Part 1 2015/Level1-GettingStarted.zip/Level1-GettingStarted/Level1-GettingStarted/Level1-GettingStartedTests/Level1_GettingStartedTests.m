//
//  Level1_GettingStartedTests.m
//  Level1-GettingStartedTests
//
//  Created by Eric Allam on 9/19/13.
//  Copyright (c) 2013 Code School. All rights reserved.
//

#import "CSRecordingTestCase.h"

@interface Level1_GettingStartedTests : CSRecordingTestCase

@end

@implementation Level1_GettingStartedTests

- (void)setUp
{
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown
{
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testConfig
{
    NSLog(@"Successfully configured");
}

@end
