#import <UIKit/UIKit.h>

@interface CSWebVC : UIViewController <UIWebViewDelegate>

@property (strong, nonatomic) UIWebView *webView;

@end
