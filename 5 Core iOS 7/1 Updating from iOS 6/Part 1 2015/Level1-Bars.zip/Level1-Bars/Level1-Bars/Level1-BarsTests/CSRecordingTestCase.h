//
//  CSRecordingTestCase.h
//  CoreiOS7ExampleProject
//
//  Created by Eric Allam on 8/29/13.
//  Copyright (c) 2013 Eric Allam. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface CSRecordingTestCase : XCTestCase

@end
