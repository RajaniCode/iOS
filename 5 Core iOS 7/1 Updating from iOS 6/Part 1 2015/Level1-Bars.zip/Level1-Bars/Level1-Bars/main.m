//
//  main.m
//  Level1-Bars
//
//  Created by Jon Friskics on 9/18/13.
//  Copyright (c) 2013 Jon Friskics. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
