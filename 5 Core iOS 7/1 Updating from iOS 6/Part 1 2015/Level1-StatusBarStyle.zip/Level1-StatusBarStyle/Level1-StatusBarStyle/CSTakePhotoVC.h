#import <UIKit/UIKit.h>

@interface CSTakePhotoVC : UIViewController <UIAlertViewDelegate>

@end
