//
//  Photo.m
//
//  Created by Eric Allam on 2/20/13.
//  Copyright (c) 2013 Code School. All rights reserved.
//

#import "Photo.h"

@implementation Photo

@end
