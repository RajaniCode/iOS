#import <UIKit/UIKit.h>

@interface PhotoViewController : UIViewController

@property (weak, nonatomic) NSString *imageFileName;
@property (weak, nonatomic) NSString *imageTitle;

@end