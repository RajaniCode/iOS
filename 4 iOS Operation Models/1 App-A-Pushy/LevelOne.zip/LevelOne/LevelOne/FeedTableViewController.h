//
//  FeedTableViewController.h
//
//  Created by Eric Allam on 11/4/12.
//  Copyright (c) 2012 Code School. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FeedTableViewController : UITableViewController

@property (strong, nonatomic) NSArray *images;

@end
