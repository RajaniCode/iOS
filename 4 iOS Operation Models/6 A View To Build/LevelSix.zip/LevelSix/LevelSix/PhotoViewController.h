#import <UIKit/UIKit.h>

@class Photo;

@interface PhotoViewController : UIViewController
@property (strong, nonatomic) Photo *photo;
@end