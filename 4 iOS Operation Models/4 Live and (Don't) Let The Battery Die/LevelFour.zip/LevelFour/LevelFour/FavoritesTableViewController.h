//
//  FavoritesTableViewController.h
//  UsingUserJson
//
//  Created by Eric Allam on 3/1/13.
//  Copyright (c) 2013 Code School. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FavoritesTableViewController : UITableViewController

@end
